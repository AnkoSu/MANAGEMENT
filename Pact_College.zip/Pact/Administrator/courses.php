<?php
session_start();

include_once("../PHP/connection.php");



if(isset($_SESSION['access'])){
 $username = $_SESSION['access'];
}
      $query = "SELECT * FROM users where username = '$username'";
        $result = mysql_query($query);
        while ($row = mysql_fetch_array($result)) {
            $First_name = $row['First_name'];
			$Last_name = $row['Last_name'];
}			
?>
<?php
$query ="";
			if(isset($_GET['level_name'])){
			$query1 = $_GET['level_name'];
		}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pact College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../side-bar/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../side-bar/css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="dashboard.php">
                        Administrators Panel
                    </a>
                </li>
                <li>
                    <a href="Examination_bodies.php">Examination Bodies</a>
                </li>
                <li>
                    <a href="courses.php">Course Level</a>
                </li>
                <li>
                    <a href="announcements.php">Announcements</a>
                </li>
                <li>
                    <a href="registration.php">User accounts</a>
                </li>
				<li>
                    <a href="messages.php">Messages</a>
                </li>
				<li>
                    <a href="notifications.php">Send Emails</a>
                </li>
                <li>
                    <a href="../PHP/Log_out.php">Log out</a>
                </li>
                
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					
						<h3 style="color:red;">Logged in as: <?php echo $First_name;?> <?php echo $Last_name; ?></h3>
                        
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Click the button</a>
                    </div>
                </div> <br>
				<div class="row">
					<div class="col-lg-12">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h4 style="color:white;">Course Level<h4>
							</div>
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-4">
										<div class="panel panel-primary">
											<div class="panel-heading">
												<h5 style="color:white;">Add Course Level<h5>
											</div>
											<div class="panel-body">
												 <form role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
													<div class="row">
														<div class="form-group col-lg-12">
															<label>Examinig body</label>
																<?php
																	$ret=mysql_query("select * from exam_bodies");
																		while($row=mysql_fetch_array($ret)){									
																		$Faculty = $row["id"];									
																	}									
																	echo"<select type='text' class='form-control'  name='id' placeholder='Exminig body'>
																	<option >Examination body</option>";
																	$query1 = "SELECT * FROM exam_bodies";
																	$result1 = mysql_query($query1);
																	while ($row1 = mysql_fetch_array($result1)):;?>
																<?php 
																	$var_ident = $row1['id'];
																	echo"<option value = '".$var_ident."'>";echo $row1['id']; echo"</option>";													  
																	endwhile; 
																	echo"</select>" 
																?>		
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Course level</label>
															<input type="text" name="level_name" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Number of units</label>
															<input type="text" name="number_of_units" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Credits</label>
															<input type="text" name="credits" required="required" class="form-control">
															<span class="error"></span>
														</div>
														 <div class="form-group col-lg-12">
															
															<button type="submit" name="submit" class="btn btn-default">Submit</button>
														</div>
														<div class="col-md-12">
															<?php
																require_once('../php/class.php');
																$app = new logic();
																if(isset($_POST['submit'])){
																	$id = $_POST['id'];
																	$level_name = $_POST['level_name'];
																	$number_of_units = $_POST['number_of_units'];
																	$credits = $_POST['credits'];
																	//$types = $_POST['types'];
						
																	$sql = "insert into course_level(id,level_name,number_of_units,credits)
																		values('$id','$level_name','$number_of_units','$credits')";
																	$app -> set_sql($sql);
																	$add = $app->execute_non_query();
						
																	if($add){
																		echo "<div class='alert alert-info'> Record added successfully</div>";
																	}else{
																		echo "<div class='alert alert-danger'> Unable to complete the operation at the current time.</div>";
																		}
																	}
															?>
														</div>
												 </form>
											</div>
										</div>
									</div>
									
									<div class="panel panel-primary">
											<div class="panel-heading">
												<h5 style="color:white;">Add Modules<h5>
											</div>
											<div class="panel-body">
												 <form role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
													<div class="row">
														
														<div class="form-group col-lg-12">
															<label>Module Code</label>
															<input type="text" name="module_code" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Name of Module</label>
															<input type="text" name="module_name" required="required" class="form-control">
															<span class="error"></span>
														</div>
														
														 <div class="form-group col-lg-12">
															
															<button type="submit" name="submit2" class="btn btn-default">Submit</button>
														</div>
														<div class="col-md-12">
															<?php
																require_once('../php/class.php');
																$app = new logic();
																if(isset($_POST['submit2'])){
																	$module_code = $_POST['module_code'];
																	$module_name = $_POST['module_name'];
																	//$number_of_units = $_POST['number_of_units'];
																	//$credits = $_POST['credits'];
																	//$types = $_POST['types'];
						
																	$sql = "insert into modules(module_code,module_name)
																		values('$module_code','$module_name')";
																	$app -> set_sql($sql);
																	$add = $app->execute_non_query();
						
																	if($add){
																		echo "<div class='alert alert-info'> Record added successfully</div>";
																	}else{
																		echo "<div class='alert alert-danger'> Unable to complete the operation at the current time.</div>";
																		}
																	}
															?>
														</div>
												 </form>
											</div>
										</div>
									</div>
									
									<div class="panel panel-primary">
											<div class="panel-heading">
												<h5 style="color:white;">Attach A Module to A Course<h5>
											</div>
											<div class="panel-body">
												 <form role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
													<div class="row">
														
														<div class="form-group col-lg-12">
															<label>Module Code</label>
															<?php
																	$ret=mysql_query("select * from modules");
																		while($row=mysql_fetch_array($ret)){									
																		$Faculty = $row["module_code"];									
																	}									
																	echo"<select type='text' class='form-control'  name='module_code' placeholder='Module Code'>
																	<option >Module Code</option>";
																	$query1 = "SELECT * FROM modules";
																	$result1 = mysql_query($query1);
																	while ($row1 = mysql_fetch_array($result1)):;?>
																<?php 
																	$var_ident = $row1['module_code'];
																	echo"<option value = '".$var_ident."'>";echo $row1['module_code']; echo"</option>";													  
																	endwhile; 
																	echo"</select>" 
																?>
																<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Course Level</label>
															<?php
																	$ret=mysql_query("select * from course_level");
																		while($row=mysql_fetch_array($ret)){									
																		$Faculty = $row["level_name"];									
																	}									
																	echo"<select type='text' class='form-control'  name='level_name' placeholder='Course_level'>
																	<option >Course Level</option>";
																	$query1 = "SELECT * FROM course_level";
																	$result1 = mysql_query($query1);
																	while ($row1 = mysql_fetch_array($result1)):;?>
																<?php 
																	$var_ident = $row1['level_name'];
																	echo"<option value = '".$var_ident."'>";echo $row1['level_name']; echo"</option>";													  
																	endwhile; 
																	echo"</select>" 
																?>
															<span class="error"></span>
														</div>
														
														 <div class="form-group col-lg-12">
															
															<button type="submit" name="submit1" class="btn btn-default">Submit</button>
														</div>
														<div class="col-md-12">
															<?php
																require_once('../php/class.php');
																$app = new logic();
																if(isset($_POST['submit1'])){
																	$module_code = $_POST['module_code'];
																	$level_name = $_POST['level_name'];
																	//$number_of_units = $_POST['number_of_units'];
																	//$credits = $_POST['credits'];
																	//$types = $_POST['types'];
						
																	$sql = "insert into module_on_course_level(module_code,level_name)
																		values('$module_code','$level_name')";
																	$app -> set_sql($sql);
																	$add = $app->execute_non_query();
						
																	if($add){
																		echo "<div class='alert alert-info'> Record added successfully</div>";
																	}else{
																		echo "<div class='alert alert-danger'> Unable to complete the operation at the current time.</div>";
																		}
																	}
															?>
														</div>
												 </form>
											</div>
										</div>
									</div>
									
									
								</div>
								<div class="col-lg-8">
									<div class="panel panel-primary">
										<div class="panel-heading">
											<h5 style="color:white;">Examination Bodies<h5>
										</div>
										<div class="panel-body">
											<div class="col-md-12">
												<table class='table'  id="dataTables-example1">
													<thead>
														<th>Body</th>
														<th>Course Level</th>
														<th>Units</th>
														<th>Credits</th>
														<th>Profile</th>
													</thead>
													<tbody>
														<?php
															$sql = "select * from course_level order by id";
															$app->set_sql($sql);
							
															$rs = $app -> execute_ret_query();
															if(is_array($rs)){
																foreach($rs as $key=>$value){
														?>
														<tr>
															<td><?php echo $value['id']; ?></td>
															<td><?php echo $value['level_name']; ?></td>
															<td><?php echo $value['number_of_units']; ?></td>
															<td><?php echo $value['credits']; ?></td>
															<td><a style="color:#337ab7" href="profile.php?level_name=<?php echo $value['level_name']; ?>"><i class="glyphicon glyphicon-send"></i></a></td>
														<?php
															
														}?>												
														</tr><?php
									
															}														
														?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../side-bar/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../side-bar/js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>

<?php
	$servername = "localhost";
	$DB_username   = "root";
	$DB_password   = "";
	$db	  		= "pact_college";
	
	//make a connection
	$conn = mysqli_connect($servername,$DB_username,$DB_password,$db);
	
	if(!$conn){
		echo "Error". mysqli_error();
	}
	else{
		echo "";
	}
	

?>
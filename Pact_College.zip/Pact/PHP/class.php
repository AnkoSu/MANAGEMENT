<?php
//session_start();

class logic{
	private $con;
	private $sql;
	//function to connect to the database
	function __construct(){
		$this->con = new mysqli('localhost','root','','pact_college');
	}
	//function to set the sql to be executed
	function set_sql($sql){
		$this->sql=$sql;
	}
		
	//function to run a query and return a value
	function execute_ret_query(){
		$query = $this->con->prepare($this->sql);
		
		if($query->execute()){
			$ret = $query->get_result();
			return $ret -> fetch_all(MYSQLI_ASSOC);
		}else{
			return $this->con->error;
		}
	}
	//function to run a query without returning a value
	function execute_non_query(){
		$query = $this->con->prepare($this->sql);
		
		if($query->execute()){
			return true;
		}else{
			return $this->con->error;
		}
	}
}
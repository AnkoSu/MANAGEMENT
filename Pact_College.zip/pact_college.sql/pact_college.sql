-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 10, 2017 at 10:16 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pact_college`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `date`, `message`) VALUES
(2, 'Professionl issues', '0000-00-00', 'The system is going to meet all the required regulations which guide the use of online market places.');

-- --------------------------------------------------------

--
-- Table structure for table `course_level`
--

CREATE TABLE IF NOT EXISTS `course_level` (
  `id` varchar(10) NOT NULL,
  `level_name` varchar(100) NOT NULL,
  `number_of_units` int(11) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL,
  PRIMARY KEY (`level_name`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_level`
--

INSERT INTO `course_level` (`id`, `level_name`, `number_of_units`, `credits`) VALUES
('CIPS', 'Advanced Certificate in Procurement and Supply Operations', 5, 0),
('CIPS', 'Certificate in Procurement and Supply Operations', 5, 0),
('CIM', 'Certificate in Professional Marketing', 4, 0),
('CIM', 'CIM Marketing Leardership', 4, 0),
('CIM', 'Digital Diploma in Professional marketing', 3, 0),
('CIPS', 'Diploma in Procurement and Supply', 5, 0),
('CIM', 'Diploma in Professional Marketing', 4, 0),
('CIM', 'Foundation Certificate in Marketing', 3, 0),
('ABE', 'Level 4 Diploma in Business Management and Human Resources', 8, 120),
('ABE', 'Level 4 Diploma in Business Management and marketing', 8, 120),
('ABMA', 'Level 4 Diploma in Community and Rural Development', 5, 0),
('ABE', 'Level 4 Foundation Diploma in Business Management', 4, 60),
('ABE', 'Level 5 Diploma in Business Management', 6, 120),
('ABE', 'Level 5 Diploma in Business Management and Human Resources', 6, 120),
('ABE', 'Level 5 Diploma in Business Management and marketing', 6, 120),
('ABMA', 'Level 5 Diploma in Community and Rural Development', 5, 0),
('ABE', 'Level 6 Diploma in Business Management', 8, 120),
('ABE', 'Level 6 Diploma in Business Management and Human Resources', 6, 120),
('ABE', 'Level 6 Diploma in Business Management and marketing', 6, 120),
('ABMA', 'Level 6 Diploma in Community and Rural Development', 5, 0),
('CIM', 'Post Diploma in Marketing Stage 1', 4, 0),
('CIM', 'Post Diploma in Marketing Stage 2', 1, 0),
('CIPS', 'Professional Diploma in Procurement and Supply', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `course_material`
--

CREATE TABLE IF NOT EXISTS `course_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `module_code` varchar(30) NOT NULL,
  `names` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module_code` (`module_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `course_material`
--

INSERT INTO `course_material` (`id`, `title`, `module_code`, `names`) VALUES
(1, 'Testing', 'ABE 003', './files/supervion list 2017.xlsx'),
(2, 'Second Upload', 'ABE 003', './files/CollabU-GProjectAssessmentSheet2009.doc'),
(3, 'The last days', 'ABE 005', './files/NSC June 2015 Marking Scheme - Final.pdf'),
(4, 'last upload', 'ABE 004', './files/literature_tech_review.ppt');

-- --------------------------------------------------------

--
-- Table structure for table `exam_bodies`
--

CREATE TABLE IF NOT EXISTS `exam_bodies` (
  `id` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_bodies`
--

INSERT INTO `exam_bodies` (`id`, `name`) VALUES
('ABE', 'Association of Business Executives'),
('ABMA', 'Association of Business Managers and Administrators'),
('ACCA', 'Association of Certified Chartered Accountants'),
('CIM', 'Chartered Institute of Marketig'),
('CIMA', 'Chartered Institute of Management Accountant'),
('CIPS', 'Chartered Institute of Procurement & Supply'),
('ICAM', 'The institute of chartered accountants in malawi');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE IF NOT EXISTS `grades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) NOT NULL,
  `grade` int(11) NOT NULL,
  `module_code` varchar(30) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `module_code` (`module_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `user_id`, `grade`, `module_code`, `comment`) VALUES
(1, 'PC0089', 68, 'ABE 002', 'Did very well on demostrations but did not explain the appropriateness of the problem domain');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `usertype` varchar(20) NOT NULL,
  `email_address1` varchar(30) NOT NULL,
  `email_address` varchar(30) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `module_code` varchar(20) NOT NULL,
  `module_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`module_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`module_code`, `module_name`) VALUES
('ABE 001', 'Dynamic Business Environments'),
('ABE 002', 'Enterprise Organisations'),
('ABE 003', 'Employability and Self Development'),
('ABE 004', 'Finance for Managers'),
('ABE 005', 'Introduction to Entrepreneurship'),
('ABE 006', 'Introduction to Qualitative Methods'),
('ABE 007', 'Project Management'),
('ABE 008', 'Principles of Marketing Practice'),
('ABE 009', 'Managing Agile organisations'),
('ABE 010', 'Innovation and Business Performance'),
('ABE 011', 'Effective Financial Management'),
('ABE 012', 'International Business Economics and Markets'),
('ABE 013', 'Intergrated Marketing Communications'),
('ABE 014', 'Buyer and Consumer Behaviour'),
('ABE 015', 'Societal and Social Marketing'),
('ABE 016', 'Leading Strategic Change'),
('ABE 017', 'Business Strategy and Decision Making'),
('ABE 018', 'Develop International Markets'),
('ABE 019', 'Business Ethics and Suistanability'),
('ABE 020', 'Strategic Marketing'),
('ABE 021', 'Strategic Marketing Relationships'),
('ABE 022', 'Digital Marketing Strategy'),
('ABE 023', 'Operational Management'),
('ABE 024', 'Analytical Decision Making'),
('ABE 025', 'Strategic Stakeholder Relationships'),
('ABE 026', 'Corporate Finance'),
('ABE 027', 'Advance Project Management'),
('ABE 028', 'Managing Stakeholder Relationships'),
('ABE 029', 'principles of Human Resource'),
('ABE 030', 'Effective Financial Management'),
('ABE 031', 'Human Resource Management'),
('ABE 032', 'Employee Management'),
('ABE 033', 'The Human Resource Management'),
('ABMA 001', 'Community Development Values'),
('ABMA 002', 'Community Health and Disease Management'),
('ABMA 003', 'Understanding Poverty in Communities'),
('ABMA 004', 'Supporting Vulnerable in Communities'),
('ABMA 005', 'Sociallogical Perspectives on Community'),
('ABMA 006', 'Business Planning and Practice for Community Organisation'),
('ABMA 007', 'Conflict Resolution and Community Campaigning'),
('ABMA 008', 'Humanitarian Aid and Crisis Management'),
('ABMA 009', 'Marketing Principles and Methods for Community Organisations'),
('ABMA 010', 'Project Finance and Funding'),
('ABMA 011', 'Community and Inter - Agency Working'),
('ABMA 012', 'Social and Community Enterprise'),
('ABMA 013', 'Intercultural Dialogue and Community Development'),
('ABMA 014', 'Reflective Practive in Community Development'),
('ABMA 015', 'Comparative Policy and Social Movements in Community Development'),
('CIM 001', 'Marketing Principles'),
('CIM 002', 'Customer Communications'),
('CIM 003', 'Digital Essentials'),
('CIM 004', 'Marketig'),
('CIM 005', 'Intergrated Communications'),
('CIM 006', 'Customer Experience'),
('CIM 007', 'Digital Marketing'),
('CIM 008', 'Strategic Marketing'),
('CIM 009', 'Mastering Metrics'),
('CIM 010', 'Driving Innovation'),
('CIM 011', 'Digital Strategy'),
('CIM 012', 'Driving Digital Experience'),
('CIM 013', 'Mastering Digital Channels'),
('CIM 014', 'Emerging Themes'),
('CIM 015', 'Analysis and Decisions'),
('CIM 016', 'Marketing Leadership and Planning'),
('CIM 017', 'Managing Corporate Reputation'),
('CIM 018', 'Leading Marketing'),
('CIM 019', 'Contemporary Challenges'),
('CIM 020', 'Leading Change'),
('CIM 021', 'Consultancy'),
('CIM 022', 'Managing Business Growth'),
('CIPS 001', 'Procurement and Supply Principles'),
('CIPS 002', 'Procurement and Supply Functions'),
('CIPS 003', 'Procurement and Supply Processes'),
('CIPS 004', 'Procurement and Supply Administration'),
('CIPS 005', 'Procurement and Supply Stakeholders'),
('CIPS 006', 'Procurement and Supply Environments'),
('CIPS 007', 'Procurement and Supply Operations'),
('CIPS 008', 'Procurement and Supply Workflow'),
('CIPS 009', 'Inventory and Logistics Operations'),
('CIPS 010', 'Procuremet and Supply Relationships'),
('CIPS 011', 'Contexts of Procurement and Supply'),
('CIPS 012', 'Business Needs in Procurement and Supply'),
('CIPS 013', 'Sourcing in Procurement and Supply'),
('CIPS 014', 'Negotiating and Contracting in Procurement and Supply'),
('CIPS 015', 'Managing Contracts and Relationships in Procurement and Supply'),
('CIPS 016', 'Leardership in procurement and supply'),
('CIPS 017', 'Corporate and Business Strategy'),
('CIPS 018', 'Strategic Supply Chain Management'),
('CIPS 019', 'Supply Chain Diligence'),
('CIPS 020', 'Programme and Project Management');

-- --------------------------------------------------------

--
-- Table structure for table `module_on_course_level`
--

CREATE TABLE IF NOT EXISTS `module_on_course_level` (
  `module_code` varchar(30) NOT NULL,
  `level_name` varchar(100) NOT NULL,
  PRIMARY KEY (`module_code`,`level_name`),
  KEY `level_name` (`level_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module_on_course_level`
--

INSERT INTO `module_on_course_level` (`module_code`, `level_name`) VALUES
('CIPS 006', 'Advanced Certificate in Procurement and Supply Operations'),
('CIPS 007', 'Advanced Certificate in Procurement and Supply Operations'),
('CIPS 008', 'Advanced Certificate in Procurement and Supply Operations'),
('CIPS 009', 'Advanced Certificate in Procurement and Supply Operations'),
('CIPS 010', 'Advanced Certificate in Procurement and Supply Operations'),
('CIPS 001', 'Certificate in Procurement and Supply Operations'),
('CIPS 002', 'Certificate in Procurement and Supply Operations'),
('CIPS 003', 'Certificate in Procurement and Supply Operations'),
('CIPS 004', 'Certificate in Procurement and Supply Operations'),
('CIPS 005', 'Certificate in Procurement and Supply Operations'),
('CIM 004', 'Certificate in Professional Marketing'),
('CIM 005', 'Certificate in Professional Marketing'),
('CIM 006', 'Certificate in Professional Marketing'),
('CIM 007', 'Certificate in Professional Marketing'),
('CIM 019', 'CIM Marketing Leardership'),
('CIM 020', 'CIM Marketing Leardership'),
('CIM 021', 'CIM Marketing Leardership'),
('CIM 022', 'CIM Marketing Leardership'),
('CIM 011', 'Digital Diploma in Professional marketing'),
('CIM 012', 'Digital Diploma in Professional marketing'),
('CIM 013', 'Digital Diploma in Professional marketing'),
('CIPS 011', 'Diploma in Procurement and Supply'),
('CIPS 012', 'Diploma in Procurement and Supply'),
('CIPS 013', 'Diploma in Procurement and Supply'),
('CIPS 014', 'Diploma in Procurement and Supply'),
('CIPS 015', 'Diploma in Procurement and Supply'),
('CIM 008', 'Diploma in Professional Marketing'),
('CIM 009', 'Diploma in Professional Marketing'),
('CIM 010', 'Diploma in Professional Marketing'),
('CIM 011', 'Diploma in Professional Marketing'),
('CIM 001', 'Foundation Certificate in Marketing'),
('CIM 002', 'Foundation Certificate in Marketing'),
('CIM 003', 'Foundation Certificate in Marketing'),
('ABE 001', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 002', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 003', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 004', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 005', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 006', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 007', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 010', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 029', 'Level 4 Diploma in Business Management and Human Resources'),
('ABE 001', 'Level 4 Diploma in Business Management and marketing'),
('ABE 002', 'Level 4 Diploma in Business Management and marketing'),
('ABE 003', 'Level 4 Diploma in Business Management and marketing'),
('ABE 004', 'Level 4 Diploma in Business Management and marketing'),
('ABE 005', 'Level 4 Diploma in Business Management and marketing'),
('ABE 006', 'Level 4 Diploma in Business Management and marketing'),
('ABE 007', 'Level 4 Diploma in Business Management and marketing'),
('ABE 008', 'Level 4 Diploma in Business Management and marketing'),
('ABE 004', 'Level 4 Diploma in Community and Rural Development'),
('ABE 005', 'Level 4 Diploma in Community and Rural Development'),
('ABMA 001', 'Level 4 Diploma in Community and Rural Development'),
('ABMA 002', 'Level 4 Diploma in Community and Rural Development'),
('ABMA 003', 'Level 4 Diploma in Community and Rural Development'),
('ABMA 004', 'Level 4 Diploma in Community and Rural Development'),
('ABMA 005', 'Level 4 Diploma in Community and Rural Development'),
('ABE 006', 'Level 5 Diploma in Business Management and Human Resources'),
('ABE 009', 'Level 5 Diploma in Business Management and Human Resources'),
('ABE 011', 'Level 5 Diploma in Business Management and Human Resources'),
('ABE 012', 'Level 5 Diploma in Business Management and Human Resources'),
('ABE 031', 'Level 5 Diploma in Business Management and Human Resources'),
('ABE 032', 'Level 5 Diploma in Business Management and Human Resources'),
('ABE 033', 'Level 5 Diploma in Business Management and Human Resources'),
('ABE 009', 'Level 5 Diploma in Business Management and marketing'),
('ABE 010', 'Level 5 Diploma in Business Management and marketing'),
('ABE 011', 'Level 5 Diploma in Business Management and marketing'),
('ABE 012', 'Level 5 Diploma in Business Management and marketing'),
('ABE 013', 'Level 5 Diploma in Business Management and marketing'),
('ABE 014', 'Level 5 Diploma in Business Management and marketing'),
('ABE 015', 'Level 5 Diploma in Business Management and marketing'),
('ABMA 006', 'Level 5 Diploma in Community and Rural Development'),
('ABMA 007', 'Level 5 Diploma in Community and Rural Development'),
('ABMA 008', 'Level 5 Diploma in Community and Rural Development'),
('ABMA 009', 'Level 5 Diploma in Community and Rural Development'),
('ABMA 010', 'Level 5 Diploma in Community and Rural Development'),
('ABMA 011', 'Level 6 Diploma in Community and Rural Development'),
('ABMA 012', 'Level 6 Diploma in Community and Rural Development'),
('ABMA 013', 'Level 6 Diploma in Community and Rural Development'),
('ABMA 014', 'Level 6 Diploma in Community and Rural Development'),
('ABMA 015', 'Level 6 Diploma in Community and Rural Development'),
('CIM 014', 'Post Diploma in Marketing Stage 1'),
('CIM 015', 'Post Diploma in Marketing Stage 1'),
('CIM 016', 'Post Diploma in Marketing Stage 1'),
('CIM 017', 'Post Diploma in Marketing Stage 1'),
('CIM 018', 'Post Diploma in Marketing Stage 2'),
('CIPS 015', 'Professional Diploma in Procurement and Supply'),
('CIPS 016', 'Professional Diploma in Procurement and Supply'),
('CIPS 017', 'Professional Diploma in Procurement and Supply'),
('CIPS 018', 'Professional Diploma in Procurement and Supply'),
('CIPS 019', 'Professional Diploma in Procurement and Supply'),
('CIPS 020', 'Professional Diploma in Procurement and Supply');

-- --------------------------------------------------------

--
-- Table structure for table `responses`
--

CREATE TABLE IF NOT EXISTS `responses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_address` varchar(40) NOT NULL,
  `response` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `responses`
--

INSERT INTO `responses` (`id`, `email_address`, `response`) VALUES
(1, 'sungainno@outlook.com', 'Chabwino zatheka boss man'),
(2, 'sungainno@outlook.com', 'hahahaha'),
(4, 'sungainno@outlook.com', 'Patsogolo mmene mau amene');

-- --------------------------------------------------------

--
-- Table structure for table `student_on_course`
--

CREATE TABLE IF NOT EXISTS `student_on_course` (
  `user_id` varchar(30) NOT NULL,
  `level_name` varchar(100) NOT NULL,
  `year` date NOT NULL,
  PRIMARY KEY (`user_id`,`level_name`),
  KEY `level_name` (`level_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_on_course`
--

INSERT INTO `student_on_course` (`user_id`, `level_name`, `year`) VALUES
('1975', 'Foundation Certificate in Marketing', '0000-00-00'),
('PC0012', 'Level 4 Diploma in Community and Rural Development', '0000-00-00'),
('PC0089', 'Level 4 Diploma in Business Management and Human Resources', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) NOT NULL,
  `names` varchar(100) DEFAULT NULL,
  `module_code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `module_code` (`module_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `user_id`, `names`, `module_code`) VALUES
(2, 'PC0089', './files/CW_COMP1646_96_ver1_16', 'ABE 001'),
(3, 'PC0089', './files/AD December 2015 Assignment MS - Final(1).pdf', 'ABE 002'),
(4, 'PC0089', './files/DDD December 2015 Assignment - Final.pdf', 'ABE 003'),
(5, 'PC0089', './files/NSC December 2015 Examination Marking Scheme - Final.pdf', 'ABE 004');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` varchar(30) NOT NULL,
  `First_name` varchar(30) NOT NULL,
  `Last_name` varchar(30) NOT NULL,
  `Date_of_birth` date DEFAULT NULL,
  `email_address` varchar(30) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `usertype` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email_address` (`email_address`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `First_name`, `Last_name`, `Date_of_birth`, `email_address`, `username`, `password`, `Gender`, `usertype`) VALUES
('1975', 'Takondwa', 'Yellow', '0000-00-00', 'tradersltd@gmail.co', 'TK', '123456', 'Male', 'Student'),
('999', 'George', 'White', '2000-08-08', 'glaisani@gmail.com', 'George', 'White', 'Male', 'Administrator'),
('PC0012', 'Mayamiko', 'Green', '0000-00-00', 'mul@gmail.com', 'Mayamiko', 'Green', 'Female', 'Student'),
('PC0089', 'Suzen', 'Brown', '0000-00-00', 'try@gmai.com', 'Suzen', '123456', 'Female', 'Student'),
('PCL001', 'Martin', 'Blue', '0000-00-00', 'innocent@yahoo.com', 'Martin', 'Blue', 'Male', 'Tutor');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course_level`
--
ALTER TABLE `course_level`
  ADD CONSTRAINT `course_level_ibfk_1` FOREIGN KEY (`id`) REFERENCES `exam_bodies` (`id`);

--
-- Constraints for table `course_material`
--
ALTER TABLE `course_material`
  ADD CONSTRAINT `course_material_ibfk_1` FOREIGN KEY (`module_code`) REFERENCES `modules` (`module_code`);

--
-- Constraints for table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `grades_ibfk_2` FOREIGN KEY (`module_code`) REFERENCES `modules` (`module_code`);

--
-- Constraints for table `module_on_course_level`
--
ALTER TABLE `module_on_course_level`
  ADD CONSTRAINT `module_on_course_level_ibfk_1` FOREIGN KEY (`module_code`) REFERENCES `modules` (`module_code`),
  ADD CONSTRAINT `module_on_course_level_ibfk_2` FOREIGN KEY (`level_name`) REFERENCES `course_level` (`level_name`);

--
-- Constraints for table `student_on_course`
--
ALTER TABLE `student_on_course`
  ADD CONSTRAINT `student_on_course_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `student_on_course_ibfk_2` FOREIGN KEY (`level_name`) REFERENCES `course_level` (`level_name`);

--
-- Constraints for table `uploads`
--
ALTER TABLE `uploads`
  ADD CONSTRAINT `uploads_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `uploads_ibfk_2` FOREIGN KEY (`module_code`) REFERENCES `modules` (`module_code`);

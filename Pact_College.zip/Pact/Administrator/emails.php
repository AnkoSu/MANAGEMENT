<?php
session_start();

include_once("../PHP/connection.php");



if(isset($_SESSION['access'])){
 $username = $_SESSION['access'];
}
      $query = "SELECT * FROM users where username = '$username'";
        $result = mysql_query($query);
        while ($row = mysql_fetch_array($result)) {
            $First_name = $row['First_name'];
			$Last_name = $row['Last_name'];
}			
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pact College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../side-bar/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../side-bar/css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="dashboard.php">
                        Administrator Panel
                    </a>
                </li>
                <li>
                    <a href="Examination_bodies.php">Examination Bodies</a>
                </li>
                <li>
                    <a href="courses.php">Course Level</a>
                </li>
                <li>
                    <a href="announcements.php">Announcements</a>
                </li>
                <li>
                    <a href="registration.php">User Accounts</a>
                </li>
				<li>
                    <a href="messages.php">Messages</a>
                </li>
				<li>
                    <a href="notifications.php">Send Emails</a>
                </li>
                <li>
                    <a href="../PHP/Log_out.php">Log out</a>
                </li>
                
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					
						<h3 style="color:red;">Logged in as: <?php echo $First_name;?> <?php echo $Last_name; ?></h3>
                        
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Click the button</a> <br><br>
                    </div>
					<br>
				<div class="row">
					<div class="col-lg-12">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h4 style="color:white;">Course Level<h4>
							</div>
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-4">
										<div class="panel panel-primary">
											<div class="panel-heading">
												<h5 style="color:white;">Add Course Level<h5>
											</div>
											<div class="panel-body">
												  <?php
					require '../PHPMailer/PHPMailerAutoload.php';
					$mysql_hostname="localhost"; // Host name
					$mysql_username="root"; // username
					$mysql_password=""; // password
					$mysql_dbname="pact_college"; // Database name
					$dbh = new PDO ("mysql:host=$mysql_hostname;dbname=$mysql_dbname",$mysql_username,$mysql_password);
					$dbh -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //setting the error codes to excemptions
					$stmt = $dbh->prepare("SELECT email_address, response from responses"); //preparing the retrieve statement from the database
					$stmt->execute(); //executing the prepared retrieve statement
					while($row = $stmt->fetch()){
					
					$email_address = $row['email_address'];
					$response = $row['response'];
					send_email($email_address,$response); //function will be called when each row in the db is executed
					}
					function send_email($email_address,$response){
					$htmlversion = "<p> To:".$email_address." <br>
					
					".$email_address."
					
					</p>";
					//$textversion; "This a text version";
					$mail = new PHPMailer;
					$mail->isSMTP();                                   // Set mailer to use SMTP
					$mail->Host = 'smtp.gmail.com';                    // Specify main and backup SMTP servers
					$mail->SMTPAuth = true;                            // Enable SMTP authentication
					$mail->Username = 'spobud2@gmail.com';          // SMTP username
					$mail->Password = 'group2@work'; // SMTP password
					$mail->SMTPSecure = 'tls';                         // Enable TLS encryption, `ssl` also accepted
					$mail->Port = 587;                                 // TCP port to connect to
					$mail->setFrom('spobud2@gmail.com', 'Pact College');
					$mail->addReplyTo('spobud2@gmail.com', 'Pact College');
					$mail->addAddress($email_address);   // Add a recipient
					//$mail->addCC('cc@example.com');
					//$mail->addBCC('bcc@example.com');
					$mail->isHTML(true);  // Set email format to HTML
					$bodyContent = '<h3 style="color:blue">Responding to your query</h3>';
					$bodyContent .= $htmlversion;
					$mail->Subject = 'Pact college ';
					$mail->Body    = $bodyContent;
					if(!$mail->send()) {
					echo 'Message could not be sent.';
					echo 'Mailer Error: ' . $mail->ErrorInfo;
					} else {
					echo 'Message has been sent';
						}
					}
				?>

											</div>
										</div>
									</div>
						
								</div>

							</div>
						</div>
					</div>
				</div>
            </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../side-bar/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../side-bar/js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>

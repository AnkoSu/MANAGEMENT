<?php
session_start();

include_once("../PHP/connection.php");



if(isset($_SESSION['access'])){
 $username = $_SESSION['access'];
}
      $query = "SELECT * FROM users where username = '$username'";
        $result = mysql_query($query);
        while ($row = mysql_fetch_array($result)) {
            $First_name = $row['First_name'];
			$Last_name = $row['Last_name'];
}			
?>
<?php
$query ="";
			if(isset($_GET['user_id'])){
			$query = $_GET['user_id'];
		}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pact College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../side-bar/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../side-bar/css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="dashboard.php">
                        Administrators Panel
                    </a>
                </li>
                <li>
                    <a href="Examination_bodies.php">Examination Bodies</a>
                </li>
                <li>
                    <a href="courses.php">Course Level</a>
                </li>
                 <li>
                    <a href="announcements.php">Announcements</a>
                </li>
                <li>
                    <a href="registration.php">User Accounts</a>
                </li>
				<li>
                    <a href="messages.php">Messages</a>
                </li>
				<li>
                    <a href="notifications.php">Send Emails</a>
                </li>
                <li>
                    <a href="../PHP/Log_out.php">Log out</a>
                </li>
               
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					
						<h3 style="color:red;">Logged in as: <?php echo $First_name;?> <?php echo $Last_name; ?></h3>
                        
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Click the button</a>
                    </div>
                </div> <br>
				<div class="row">
					<div class="col-lg-12">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h4 style="color:white;">User accounts<h4>
							</div>
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-3">
										<div class="panel panel-primary">
											<div class="panel-heading">
												<h5 style="color:white;">Add User<h5>
											</div>
											<div class="panel-body">
												 <form role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
													<div class="row">
														<div class="form-group col-lg-12">
															<label>Identication number</label>
															<input type="text" name="user_id" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>First name</label>
															<input type="text" name="First_name" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Last name</label>
															<input type="text" name="Last_name" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Date of birth</label>
															<input type="text" name="Date_of_birth" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Email address</label>
															<input type="email" name="email_address" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Username</label>
															<input type="text" name="username" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Password</label>
															<input type="password" name="password" required="required" class="form-control">
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>Gender</label>
															<select name="Gender" required="required" class="form-control">
																<option>Female</option>
																<option>Male</option>
															</select>
															<span class="error"></span>
														</div>
														<div class="form-group col-lg-12">
															<label>User type</label>
																<select name="usertype" required="required" class="form-control">
																<option>Administrator</option>
																<option>Student</option>
																<option>Tutor</option>
															</select>
															<span class="error"></span>
														</div>
														 <div class="form-group col-lg-12">
															
															<button type="submit" name="submit" class="btn btn-default">Submit</button>
														</div>
														<div class="col-md-12">
															<?php
																require_once('../php/class.php');
																$app = new logic();
																if(isset($_POST['submit'])){
																	$user_id = $_POST['user_id'];
																	$First_name = $_POST['First_name'];
																	$Last_name = $_POST['Last_name'];
																	$Date_of_birth = $_POST['Date_of_birth'];
																	$email_address = $_POST['email_address'];
																	$username= $_POST['username'];
																	$password = $_POST['password'];
																	$Gender = $_POST['Gender'];
																	$usertype = $_POST['usertype'];
						
																	$sql = "insert into users(user_id,First_name,Last_name,Date_of_birth,email_address,username,password,Gender,usertype)
																		values('$user_id','$First_name','$Last_name','$Date_of_birth','$email_address','$username','$password','$Gender','$usertype')";
																	$app -> set_sql($sql);
																	$add = $app->execute_non_query();
						
																	if($add){
																		echo "<div class='alert alert-info'> Record added successfully</div>";
																	}else{
																		echo "<div class='alert alert-danger'> Unable to complete the operation at the current time.</div>";
																		}
																	}
															?>
														</div>
												 </form>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-9">
									<div class="panel panel-primary">
										<div class="panel-heading">
											<h5 style="color:white;">System Users<h5>
										</div>
										<div class="panel-body">
											<div class="col-md-12">
												<table class='table'  id="dataTables-example1">
													<thead>
														<th>ID</th>
														<th>Forename</th>
														<th>Surname</th>
														<th>D. 0. B</th>
														<th>Email</th>
														
														<th>Gender</th>
														<th>User type</th>
														
														<th>Assign</th>
													</thead>
													<tbody>
														<?php
															$sql = "select * from users";
															$app->set_sql($sql);
							
															$rs = $app -> execute_ret_query();
															if(is_array($rs)){
																foreach($rs as $key=>$value){
														?>
														<tr>
															<td><?php echo $value['user_id']; ?></td>
															<td><?php echo $value['First_name']; ?></td>
															<td><?php echo $value['Last_name']; ?></td>
															<td><?php echo $value['Date_of_birth']; ?></td>
															<td><?php echo $value['email_address']; ?></td>
															
															<td><?php echo $value['Gender']; ?></td>
															<td><?php echo $value['usertype']; ?></td>
															<td><a style="color:#337ab7" href="assignment.php?user_id=<?php echo $value['user_id']; ?>"><i class="glyphicon glyphicon-send"></i></a></td>
														<?php
														
														}?>												
														</tr><?php
									
															}														
														?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../side-bar/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../side-bar/js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>

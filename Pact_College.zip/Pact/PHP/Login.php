<?php
	session_start();

	$host="localhost"; // Host name
	$username="root"; // username
	$password=""; // password
	$db_name="pact_college"; // Database name

	// Replace database connect functions depending on database you are using.
	mysql_connect("$host", "$username", "$password");
	mysql_select_db("$db_name");

	//Database connection
	$dbconn = mysql_connect($host, $username, $password);


	// username and password sent from form
	$username=mysql_real_escape_string($_POST['username']);
	$password = mysql_real_escape_string($_POST['password']);

 
	$sql=("SELECT * FROM users WHERE username='$username' and password='$password'");
	$result=mysql_query($sql);

	$fetch = mysql_fetch_array($result);
	if ($fetch>1){
		$Role = $fetch["usertype"]; 
		$username = $fetch["username"]; 
		$_SESSION['access'] = $username; 


		if($Role==='Student'){
			header('location:../student/home.php');
		}
		elseif ($Role =='Administrator') {
			header('location:../Administrator/dashboard.php');
		}
		elseif($Role == 'Tutor'){
			header('location:../tutor/tutor.php');
		} 
		elseif($Role == 'Guest') {
			header('location:guestdashboard.php');
		}



	}
	else {
		echo "Access Denied";
	}


?>
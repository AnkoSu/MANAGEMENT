<?php
session_start();

include_once("../PHP/connection.php");



if(isset($_SESSION['access'])){
 $username = $_SESSION['access'];
}
      $query = "SELECT * FROM users where username = '$username'";
        $result = mysql_query($query);
        while ($row = mysql_fetch_array($result)) {
            $First_name = $row['First_name'];
			$Last_name = $row['Last_name'];
}			
?>
<?php
$query ="";
			if(isset($_GET['user_id'])){
			$query = $_GET['user_id'];
		}
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pact College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../side-bar/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../side-bar/css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="dashboard.php">
                        Administrator Panel
                    </a>
                </li>
                <li>
                    <a href="Examination_bodies.php">Examination Bodies</a>
                </li>
                <li>
                    <a href="courses.php">Course Level</a>
                </li>
                <li>
                    <a href="announcements.php">Announcements</a>
                </li>
                <li>
                    <a href="registration.php">User Accounts</a>
                </li>
				<li>
                    <a href="messages.php">Messages</a>
                </li>
				<li>
                    <a href="notifications.php">Send Emails</a>
                </li>
                <li>
                    <a href="../PHP/Log_out.php">Log out</a>
                </li>
                
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					
						<h3 style="color:red;">Logged in as: <?php echo $First_name;?> <?php echo $Last_name; ?></h3> 
                        
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Click the button</a><br> <br>
                    </div>
                </div>
				<div class="row">
                    <div class="col-lg-12">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h4 style="color:white;">Students attached to courses<h4>
							</div>
							<div class="panel-body">
								<div class="row">
									<div class="col-md-4">
										<div class="panel panel-primary">
											<div class="panel-heading">
												<h5 style="color:white;">Assign student to a course<h5>
											</div>
											<div class="panel-body">
												<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
													<div class="row">
														<div class="form-group col-lg-12">
															<label>Student id</label>
															<input type="text" name="user_id" value="<?php echo $query; ?>" required="required" class="form-control">
															<span class="error"></span>												
														</div>
														<div class="form-group col-lg-12">
															<label>Course title</label>
															<?php
																	$ret=mysql_query("select * from course_level");
																		while($row=mysql_fetch_array($ret)){									
																		$Faculty = $row["level_name"];									
																	}									
																	echo"<select type='text' class='form-control'  name='level_name' placeholder='Course_level'>
																	<option >Course Level</option>";
																	$query1 = "SELECT * FROM course_level";
																	$result1 = mysql_query($query1);
																	while ($row1 = mysql_fetch_array($result1)):;?>
																<?php 
																	$var_ident = $row1['level_name'];
																	echo"<option value = '".$var_ident."'>";echo $row1['level_name']; echo"</option>";													  
																	endwhile; 
																	echo"</select>" 
																?>
															<span class="error"></span>												
														</div>
														<div class="form-group col-lg-12">
															<label>Year</label>
															<input type="text" name="year" required="required" class="form-control">
															<span class="error"></span>												
														</div>
														<div class="form-group col-lg-12">
															
															<button type="submit" name="submit" class="btn btn-default">Submit</button>
														</div>
														

													</div>
													<?php
																require_once('../php/class.php');
																$app = new logic();
																if(isset($_POST['submit'])){
																	$user_id = $_POST['user_id'];
																	$level_name = $_POST['level_name'];
																	$year = $_POST['year'];
																	//$contact = $_POST['contact'];
																	//$types = $_POST['types'];
						
																	$sql = "insert into student_on_course(user_id,level_name,year)
																		values('$user_id','$level_name','$year')";
																	$app -> set_sql($sql);
																	$add = $app->execute_non_query();
						
																	if($add){
																		echo "<div class='alert alert-info'> Record added successfully</div>";
																	}else{
																		echo "<div class='alert alert-danger'> Unable to complete the operation at the current time.</div>";
																		}
																	}
															?>
												</form>
											</div>
										</div>
									</div>
									<div class="col-md-8">
										<div class="panel panel-primary">
											<div class="panel-heading">
												<h5 style="color:white;">Students on a course<h5>
											</div>
											<div class="panel-body">
												<table class='table'  id="dataTables-example1">
											<thead>
												<th>First Name</th>
												<th>Last Name</th>
												<th>Course</th>
												<th>Year</th>
												<th>Body</th>
												
											</thead>
											<tbody>
												<?php
													$sql = "select users.first_name,users.last_name,course_level.level_name,student_on_course.year,
													course_level.id from users,course_level,student_on_course
													where course_level.level_name=student_on_course.level_name and 
													users.user_id=student_on_course.user_id";
													$app->set_sql($sql);
							
													$rs = $app -> execute_ret_query();
														if(is_array($rs)){
															foreach($rs as $key=>$value){
												?>
												<tr>
													<td><?php echo $value['first_name']; ?></td>
													<td><?php echo $value['last_name']; ?></td>
													<td><?php echo $value['level_name']; ?></td>
													<td><?php echo $value['year']; ?></td>
													<td><?php echo $value['id']; ?></td>													
												<?php
														
												}?>												
												</tr><?php
									
													}														
												?>
											</tbody>
										</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../side-bar/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../side-bar/js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>

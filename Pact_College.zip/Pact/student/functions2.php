<?php
	class functions2{
		private $con;
		
		function __construct(){
			$this->con = new mysqli ('localhost','root','','pact_college');
		}
		
		function myresponses($username){
			$sql = ' select users.first_name,users.last_name,modules.module_name,grades.comment 
			from grades,users,modules where users.user_id=grades.user_id and
			modules.module_code=grades.module_code and users.username =?';
			$query = $this->con->prepare($sql);
			$query -> bind_param('s',$username); //This function binds the parameters to the SQL query and tells the database what the parameters are
						
			if($query->execute()){
				$ret = $query->get_result();
				return $ret->fetch_all(MYSQLI_ASSOC);
			}else{
				echo $query->error;
			}
		}
		
		function mygrade($username){
			$sql = ' select users.first_name,users.last_name,modules.module_name,grades.grade 
			from grades,users,modules where users.user_id=grades.user_id and
			modules.module_code=grades.module_code and users.username =?';
			$query = $this->con->prepare($sql);
			$query -> bind_param('s',$username); //This function binds the parameters to the SQL query and tells the database what the parameters are
						
			if($query->execute()){
				$ret = $query->get_result();
				return $ret->fetch_all(MYSQLI_ASSOC);
			}else{
				echo $query->error;
			}
		}
		
		function mydetails($username){
			$sql = ' select user_id,first_name,last_name,Date_of_birth,email_address,gender from users where username =?';
			$query = $this->con->prepare($sql);
			$query -> bind_param('s',$username); //This function binds the parameters to the SQL query and tells the database what the parameters are
						
			if($query->execute()){
				$ret = $query->get_result();
				return $ret->fetch_all(MYSQLI_ASSOC);
			}else{
				echo $query->error;
			}
		}
		
		function mydetails2($username){
			$sql = ' SELECT exam_bodies.id, course_level.level_name, modules.module_name
			FROM modules, users, student_on_course, course_level, exam_bodies, module_on_course_level
			WHERE exam_bodies.id = course_level.id
			AND users.user_id = student_on_course.user_id
			AND course_level.level_name = student_on_course.level_name
			AND modules.module_code = module_on_course_level.module_code
			AND course_level.level_name = module_on_course_level.level_name AND users.username =?';
			$query = $this->con->prepare($sql);
			$query -> bind_param('s',$username); //This function binds the parameters to the SQL query and tells the database what the parameters are
						
			if($query->execute()){
				$ret = $query->get_result();
				return $ret->fetch_all(MYSQLI_ASSOC);
			}else{
				echo $query->error;
			}
		}

	}	
?>
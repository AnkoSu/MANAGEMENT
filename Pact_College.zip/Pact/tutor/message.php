<?php
session_start();

include_once("../PHP/connection.php");



if(isset($_SESSION['access'])){
 $username = $_SESSION['access'];
}
      $query = "SELECT * FROM users where username = '$username'";
        $result = mysql_query($query);
        while ($row = mysql_fetch_array($result)) {
            $First_name = $row['First_name'];
			$Last_name = $row['Last_name'];
}			
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pact College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../side-bar/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../side-bar/css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="tutor.php">
                        Tutors Panel
                    </a>
                </li>
                <li>
                    <a href="assignments.php">Assignment downlods</a>
                </li>
                <li>
                    <a href="comments.php">Grades and Comments</a>
                </li>
                <li>
                    <a href="message.php">Message administrator</a>
                </li>
				<li>
                    <a href="course_material.php">Upload Course Material</a>
                </li>
                
                <li>
                    <a href="../PHP/Log_out.php">Log out</a>
                </li>
               
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					
						<h3 style="color:red;">Logged in as: <?php echo $First_name;?> <?php echo $Last_name; ?></h3>
                        
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Click the button</a> <br></br>
                    </div>
					
					<div class="row">
						<div class="col-lg-12">
							<div class="panel panel-primary">
								<div class="panel-heading">
									<h4 style="color:white;">Send message<h4>
								</div>
								<div class="panel-body">
									<div class="row">
										<div class="col-md-6 col-md-offset-3">
											<div class="panel panel-primary">
												<div class="panel-heading">
													<h4 style="color:white;">Send Message<h4>
												</div>
												<div class="panel-body">
													<form method="post" role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
														<div class="row">
														
															<div class="form-group col-lg-12">
																<label>Message from</label>
																	<select name="usertype" required="required" class="form-control">
																		<option>Tutor</option>
																	</select>
																<span class="error"></span>
															</div>
															
															<div class="form-group col-lg-12">
																<label>Senders Email Address</label>
																<input type="email" name="email_address1" required="required" class="form-control">
																<span class="error"></span>
															</div>
															
															<div class="form-group col-lg-12">
															<label>Email Address</label>
															<?php
																	$ret=mysql_query("select * from users where usertype='administratot'");
																		while($row=mysql_fetch_array($ret)){									
																		$Faculty = $row["email"];									
																	}									
																	echo"<select type='text' class='form-control'  name='email_address' placeholder='Email address'>
																	<option >Administrator Email Address</option>";
																	$query1 = "SELECT * FROM users where usertype='administrator'";
																	$result1 = mysql_query($query1);
																	while ($row1 = mysql_fetch_array($result1)):;?>
																<?php 
																	$var_ident = $row1['email_address'];
																	echo"<option value = '".$var_ident."'>";echo $row1['email_address']; echo"</option>";													  
																	endwhile; 
																	echo"</select>" 
																?>
																<span class="error"></span>
															</div>
															<div class="form-group col-lg-12">
																<label>Message</label>
																<textarea type="text" rows="3" name="message" required="required" class="form-control"></textarea>
																<span class="error"></span>
															</div>
															<div class="form-group col-lg-12">
															
															<button type="submit" name="submit" class="btn btn-default">Submit</button>
															</div>
															<div class="col-md-12">
															<?php
																require_once('../php/class.php');
																$app = new logic();
																if(isset($_POST['submit'])){
																	$usertype = $_POST['usertype'];
																	$email_address1 = $_POST['email_address1'];
																	$email_address = $_POST['email_address'];
																	$message = $_POST['message'];
																	
																	$sql = "insert into messages(message_id,usertype,email_address1,email_address,message)
																		values('','$usertype','$email_address1','$email_address','$message')";
																	$app -> set_sql($sql);
																	$add = $app->execute_non_query();
						
																	if($add){
																		echo "<div class='alert alert-info'> Record added successfully</div>";
																	}else{
																		echo "<div class='alert alert-danger'> Unable to complete the operation at the current time.</div>";
																		}
																	}
															?>
														</div>
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../side-bar/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../side-bar/js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>

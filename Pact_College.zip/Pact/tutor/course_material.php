<?php
session_start();

include_once("../PHP/connection.php");



if(isset($_SESSION['access'])){
 $username = $_SESSION['access'];
}
      $query = "SELECT * FROM users where username = '$username'";
        $result = mysql_query($query);
        while ($row = mysql_fetch_array($result)) {
            $First_name = $row['First_name'];
			$Last_name = $row['Last_name'];
}			
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pact College</title>

    <!-- Bootstrap Core CSS -->
    <link href="../side-bar/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../side-bar/css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="tutor.php">
                        Tutors Panel
                    </a>
                </li>
                <li>
                    <a href="assignments.php">Assignment downlods</a>
                </li>
                <li>
                    <a href="comments.php">Grades and Comments</a>
                </li>
                <li>
                    <a href="message.php">Message administrator</a>
                </li>
                <li>
                    <a href="ourse_material.php">Upload Course Material</a>
                </li>
                <li>
                    <a href="../PHP/Log_out.php">Log out</a>
                </li>
               
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
					
						<h3 style="color:red;">Logged in as: <?php echo $First_name;?> <?php echo $Last_name; ?></h3>
                        
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Click the button</a> <br></br>
                    </div>
					
					<div class="row">
						<div class="col-lg-12">
							<div class="panel panel-primary">
								<div class="panel-heading">
									<h4 style="color:white;">Upload Course Material<h4>
								</div>
								<div class="panel-body">
									<div class="row">
										<div class="col-md-6 col-md-offset-3">
											<div class="panel panel-primary">
												<div class="panel-heading">
													<h4 style="color:white;">Upload Course Material<h4>
												</div>
												<div class="panel-body">
												
												<?php
						
							if (isset($_FILES["upload"])){
								$allowed_exts = array('doc','DOC','docx','DOCX','PDF','pdf','PPT','ppt','XLSX','xlsx');
								$ext = strtolower(substr($_FILES['upload']['name'], strrpos($_FILES['upload']['name'], '.') + 1));	
								$errors = array();	
								$title = $_POST['title'];
								$module_code = $_POST['module_code'];								
								$location="./files/". $_FILES["upload"]["name"];
																
								if (in_array($ext, $allowed_exts) === false){
								$errors[] = '<p class="error">You can only UPLOAD Word Documents and PDF files</p>';
								}
								if ($_FILES['upload']['size'] > 100000000){
									$errors[] = 'The file was too large';
								}
								if (empty($errors)){
									move_uploaded_file($_FILES['upload']['tmp_name'], "./files/{$_FILES['upload']['name']}");
		
									require("../student/db_connect2.php");
	
									$insert_into_db = mysqli_query($conn,"INSERT INTO course_material 
										(id,title,module_code,names)	
										VALUES('','$title','$module_code','$location')");
	
										if($insert_into_db){
											//$_SESSION['access'] = "Successfully uploaded";
												Header("location:course_material.php");
												
					
										}
										}else{
										foreach ($errors as $error) {
										//$_SESSION['access']=$error;
										Header("location: course_material.php");
										}
									}
	
	
							}
						?>
												
													<form method="post" role="form" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
														<div class="row">
														
																												
															<div class="form-group col-lg-12">
																<label>Title</label>
																<input type="text" name="title" required="required" class="form-control">
																<span class="error"></span>
															</div>
															<div class="form-group col-lg-12">
															<label>Module Code</label>
															<?php
																	$ret=mysql_query("select * from modules");
																		while($row=mysql_fetch_array($ret)){									
																		$Faculty = $row["module_code"];									
																	}									
																	echo"<select type='text' class='form-control'  name='module_code' placeholder='Module Code'>
																	<option >Module Code</option>";
																	$query1 = "SELECT * FROM modules";
																	$result1 = mysql_query($query1);
																	while ($row1 = mysql_fetch_array($result1)):;?>
																<?php 
																	$var_ident = $row1['module_code'];
																	echo"<option value = '".$var_ident."'>";echo $row1['module_code']; echo"</option>";													  
																	endwhile; 
																	echo"</select>" 
																?>
																<span class="error"></span>
														</div>
															<div class="form-group col-lg-12">
																<label>File to upload</label>
																<input type="file" id="names" name="upload" class="form-control">
																<span class="error"></span>												
															</div>
															<div class="form-group col-lg-12">
															
															<button type="submit" name="submit" class="btn btn-default">Submit</button>
															</div>
															
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../side-bar/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../side-bar/js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>

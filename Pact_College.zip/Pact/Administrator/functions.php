<?php
	class functions{
		private $con;
		
		function __construct(){
			$this->con = new mysqli ('localhost','root','','pact_college');
		}
		
		
		
		function deleteresponse($id){
			$sql = 'delete from responses where id=?';
			$query = $this->con->prepare($sql);
			$query -> bind_param('s',$id);
			
			if($query->execute()){
				return true;
			}else{
				return false;
			}
		}
		
		function deletemessages($message_id){
			$sql = 'delete from messages where message_id=?';
			$query = $this->con->prepare($sql);
			$query -> bind_param('s',$message_id);
			
			if($query->execute()){
				return true;
			}else{
				return false;
			}
		}
		

		
		
		function deleteannouncements($id){
			$sql = 'delete from announcements where id=?';
			$query = $this->con->prepare($sql);
			$query -> bind_param('s',$id);
			
			if($query->execute()){
				return true;
			}else{
				return false;
			}
		}
		
		
		
		
	}
?>
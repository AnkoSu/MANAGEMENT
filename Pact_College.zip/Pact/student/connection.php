<?php
$host="localhost"; // Host name
$username="root"; // username
$password=""; // password
$db_name="pact_college"; // Database name

// Replace database connect functions depending on database you are using.
mysql_connect("$host", "$username", "$password");
mysql_select_db("$db_name");

//Database connection
$dbconn = mysql_connect($host, $username, $password);
?>